package com.insurance_management_platform.InsuranceManagementPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceManagementPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
