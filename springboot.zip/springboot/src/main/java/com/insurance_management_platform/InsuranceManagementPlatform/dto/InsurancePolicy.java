package com.insurance_management_platform.InsuranceManagementPlatform.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class InsurancePolicy extends Client
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String policyNumber;
	private String policyType;
	private double coverageAmount;
	private int premium;
	private String startDate;
	private String endDate;
	
	
	public int getId() 
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getPolicyNumber() 
	{
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber)
	{
		this.policyNumber = policyNumber;
	}
	public String getPolicyType()
	{
		return policyType;
	}
	public void setPolicyType(String policyType)
	{
		this.policyType = policyType;
	}
	public double getCoverageAmount() 
	{
		return coverageAmount;
	}
	public void setCoverageAmount(double coverageAmount) 
	{
		this.coverageAmount = coverageAmount;
	}
	public int getPremium() 
	{
		return premium;
	}
	public void setPremium(int premium) 
	{
		this.premium = premium;
	}
	public String getStartDate() 
	{
		return startDate;
	}
	public void setStartDate(String startDate) 
	{
		this.startDate = startDate;
	}
	public String getEndDate() 
	{
		return endDate;
	}
	public void setEndDate(String endDate) 
	{
		this.endDate = endDate;
	}
	
	
}
