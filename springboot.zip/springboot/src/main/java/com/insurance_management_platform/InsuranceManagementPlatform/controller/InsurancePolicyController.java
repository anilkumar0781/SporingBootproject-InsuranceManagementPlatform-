package com.insurance_management_platform.InsuranceManagementPlatform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.insurance_management_platform.InsuranceManagementPlatform.dao.InsurancePolicyDao;
import com.insurance_management_platform.InsuranceManagementPlatform.dto.InsurancePolicy;

@RestController
public class InsurancePolicyController 
{
	@Autowired
	InsurancePolicyDao dao;
	
	@GetMapping("/insurancepolicy")
	public List<InsurancePolicy> dispalyAll()
	{
		return dao.displayAll();
	}
	
	@GetMapping("/byid")
	public InsurancePolicy findById(int id)
	{
		return dao.findById(id);
	}
	
	@PostMapping("/insurancepolicy")
	public InsurancePolicy saveInsurancePolicy(@RequestBody InsurancePolicy insurancepolicy)
	{
		return dao.insertInsurancePolicy(insurancepolicy);
	}
	
	@PutMapping("/insurancepolicy")
	public InsurancePolicy updateInsurancePolicy(@RequestParam int id, @RequestBody InsurancePolicy newInsurancePolicy)
	{
		return dao.updateInsurancePolicy(id, newInsurancePolicy);
	}
	
	@DeleteMapping("/insurancepolicy")
	public String deleteById(@RequestParam int id)
	{
		boolean b = dao.deleteById(id);
		if(b)
		{
			return "Deleted successfully";
		}
		else
		{
			return "Not present in the database";
		}
	}
}

