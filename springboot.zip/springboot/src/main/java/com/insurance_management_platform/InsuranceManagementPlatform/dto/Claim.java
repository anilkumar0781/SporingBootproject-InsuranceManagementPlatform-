package com.insurance_management_platform.InsuranceManagementPlatform.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Claim extends InsurancePolicy 
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String claimNumber;
	private String description;
	private String claimDate;
	private String claimStatus;
	
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getClaimNumber() 
	{
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) 
	{
		this.claimNumber = claimNumber;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public String getClaimDate() 
	{
		return claimDate;
	}
	public void setClaimDate(String claimDate) 
	{
		this.claimDate = claimDate;
	}
	public String getClaimStatus() 
	{
		return claimStatus;
	}
	public void setClaimStatus(String claimStatus) 
	{
		this.claimStatus = claimStatus;
	}
	
	
	
}
