package com.insurance_management_platform.InsuranceManagementPlatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication//(exclude = {DataSourceAutoConfiguration.class })
public class InsuranceManagementPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceManagementPlatformApplication.class, args);
		
		System.out.println("Application Started.....");
	}

}
 