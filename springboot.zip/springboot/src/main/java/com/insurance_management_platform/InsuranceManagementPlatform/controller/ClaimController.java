package com.insurance_management_platform.InsuranceManagementPlatform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.insurance_management_platform.InsuranceManagementPlatform.dao.ClaimDao;
import com.insurance_management_platform.InsuranceManagementPlatform.dto.Claim;


@RestController
public class ClaimController 
{
	@Autowired
	ClaimDao dao;
	
	
	@GetMapping("/claim")
	public List<Claim> displayAll()
	{
		return dao.displayAll();
	}
	
	@GetMapping("/claimbyid")
	public Claim findById(@RequestParam int id)
	{
		return dao.findById(id);
	}
	
	@PostMapping("/claim")
	public Claim saveClaim(@RequestBody Claim claim)
	{
		return dao.insertClaim(claim);
	}
	
	@PutMapping("/claim")
	public Claim updateClaim(@RequestParam int id, @RequestBody Claim claim)
	{
		return dao.updateClaim(id, claim); 
	}
	
	@DeleteMapping("/claim")
	public String deleteById(@RequestParam int id)
	{
		boolean b = dao.deleteById(id);
		if(b)
		{
			return "Deleted Successfully";
		}
		else
		{
			return "It is not present in the database";
			
		}
	}
}

