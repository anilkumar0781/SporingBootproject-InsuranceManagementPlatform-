package com.insurance_management_platform.InsuranceManagementPlatform.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance_management_platform.InsuranceManagementPlatform.dto.InsurancePolicy;
import com.insurance_management_platform.InsuranceManagementPlatform.repository.InsurancePolicyRepository;

@Repository
public class InsurancePolicyDao
{
	@Autowired
	InsurancePolicyRepository repository;
	
	public List<InsurancePolicy> displayAll()
	{
		return repository.findAll();
	}
	
	public InsurancePolicy findById(int id)
	{
		Optional<InsurancePolicy> opt = repository.findById(id);
		if(opt.isPresent())
		{
			return opt.get();
		}
		else
		{
			return null;
		}
	}
	
	public InsurancePolicy insertInsurancePolicy(@RequestBody InsurancePolicy insurancepolicy)
	{
		return repository.save(insurancepolicy);
	}
	
	public InsurancePolicy updateInsurancePolicy(@RequestParam int id , @RequestBody InsurancePolicy newInsurancePolicy)
	{
		InsurancePolicy existingInsurancePolicy = findById(id);
		if(existingInsurancePolicy != null)
		{
			return repository.save(newInsurancePolicy);
		}
		else
		{
			return null;
		}
	}
	
	public boolean deleteById(int id)
	{
		InsurancePolicy b = findById(id);
		if(b != null)
		{
			repository.deleteById(id);
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
