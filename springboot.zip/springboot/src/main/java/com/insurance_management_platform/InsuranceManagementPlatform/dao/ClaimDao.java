package com.insurance_management_platform.InsuranceManagementPlatform.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance_management_platform.InsuranceManagementPlatform.dto.Claim;
import com.insurance_management_platform.InsuranceManagementPlatform.repository.ClaimRepository;



@Repository
public class ClaimDao 
{
	
	@Autowired
	ClaimRepository repository;
	
	// 1.Fetch (or) Display all Claims....
	public List<Claim> displayAll()
	{
		return repository.findAll();
	}
	
	// 2.Fetch a specific Claim By Id....
	public Claim findById(int id)
	{
		Optional <Claim> opt = repository.findById(id);
		if(opt.isPresent())
		{
			return opt.get();
		}
		else
		{
			return null;
		}
	}
	
	// 3.Create a new Claim..
	public Claim insertClaim(Claim claim)
	{
		return repository.save(claim);
	}
	
	// 4.Update a Claim's information..
	public Claim updateClaim(int id, Claim newClaim)
	{
		Claim existingClaim = findById(id);
		if(existingClaim != null)
		{
			return repository.save(newClaim);
		}
		else
		{
			return null;
		}
	}
	
	// 5.Delete a Claim...
	public boolean deleteById(int id)
	{
		Claim c = findById(id);
		if(c!=null)
		{
			repository.deleteById(id);
			return true;
		}
		else
		{
			return false;
		}
	}
}

