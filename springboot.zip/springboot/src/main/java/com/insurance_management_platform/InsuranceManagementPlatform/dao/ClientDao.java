package com.insurance_management_platform.InsuranceManagementPlatform.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance_management_platform.InsuranceManagementPlatform.dto.Client;
import com.insurance_management_platform.InsuranceManagementPlatform.repository.ClientRepository;


@Repository
public class ClientDao 
{
	@Autowired
	ClientRepository repository;
	
	public List<Client> displayAll()
	{
		return repository.findAll();
	}
	
	public Client findById(int id)
	{
		Optional<Client> opt = repository.findById(id);
		if(opt.isPresent())
		{
			return opt.get();
		}
		else
		{
			return null;
		}
	}
	
	public Client insertClient(@RequestBody Client client)
	{
		return repository.save(client);
	}
	
	public Client updateClient(@RequestParam int id , @RequestBody Client newClient)
	{
		Client existingClient = findById(id);
		if(existingClient != null)
		{
			return repository.save(newClient);
		}
		else
		{
			return null;
		}
	}
	
	public boolean deleteById(int id)
	{
		Client b = findById(id);
		if(b != null)
		{
			repository.deleteById(id);
			return true;
		}
		else
		{
			return false;
		}
	}
}