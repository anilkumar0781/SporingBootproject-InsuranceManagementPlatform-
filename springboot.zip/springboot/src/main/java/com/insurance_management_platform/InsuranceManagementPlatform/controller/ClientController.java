package com.insurance_management_platform.InsuranceManagementPlatform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.insurance_management_platform.InsuranceManagementPlatform.dao.ClientDao;

import com.insurance_management_platform.InsuranceManagementPlatform.dto.Client;

@RestController
public class ClientController 
{
	@Autowired
	ClientDao dao;
	
	@GetMapping("/client")
	public List<Client> displayAll()
	{
		return dao.displayAll();
	}
	
	@GetMapping("/clientbyid")
	public Client findById(@RequestParam int id)
	{
		return dao.findById(id);
	}
	
	@PostMapping("/client")
	public Client saveClient(@RequestBody Client client)
	{
		return dao.insertClient(client);
	}
	
	@PutMapping("/client")
	public Client updateClient(@RequestParam int id, @RequestBody Client client)
	{
		return dao.updateClient(id, client); 
	}
	
	@DeleteMapping("/client")
	public String deleteById(@RequestParam int id)
	{
		boolean b = dao.deleteById(id);
		if(b)
		{
			return "Deleted Successfully";
		}
		else
		{
			return "It is not present in the database";
			
		}
	}
}